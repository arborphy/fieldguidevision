# BioImages representation analysis

This directory analyzes saved frozen BioCLIP and DINOv3 embeddings. It does not train a model, rerun inference, name clusters, or generate morphology explanations.

The EfficientNet-B0 ImageNet-supervised frozen-representation control is reported separately in `efficientnet_control.html`. Its k=20 analysis uses the same normalized-embedding K-means settings and exact DINOv3 manifest.

## Protocol

- Embedding universe: 1,641 images from the strict individual-disjoint split.
- Test error overlay: the existing 211-image four-baseline prediction table.
- K-means: k=10, 20, 50; labels excluded; random seed 42; n_init=20.
- Similarity: cosine similarity on normalized embeddings.
- Nearest-neighbor galleries exclude all images from the query observation.
- Error enrichment: post-hoc hypergeometric tests with BH correction, plus explicitly labeled descriptive thresholds.
- PCA and UMAP: global 1,641-image projections, used only for visualization.

Mean BioCLIP/DINO cross-observation neighbor overlap@10: 0.2839.

Image download failures while building contact sheets: 0.

## Outputs

- `report.html`: meeting-ready static report.
- `efficientnet_control.html`: EfficientNet benchmark plus the three-representation k=20 comparison and EfficientNet cluster atlas.
- `data/frozen_probe_comparison.csv`: BioCLIP, DINOv3 and EfficientNet frozen linear-probe species/genus/family results.
- `data/efficientnet_k20_cluster_summary.csv` and `data/efficientnet_k20_cluster_assignments.csv`: EfficientNet k=20 composition and assignments.
- `data/three_representation_k20_summary.csv` and `data/three_representation_k20_pairwise_ari.csv`: aligned post-hoc structure metrics for all three spaces.
- `data/cluster_summary.csv`: cluster composition, purity, organ distribution, four-baseline test accuracy and enrichment statistics.
- `data/cluster_assignments.csv`: every image assignment and centroid distance for both spaces and all k values.
- `data/nearest_neighbors.csv`: all and cross-observation Top-10 neighbors for every test image in both spaces.
- `data/confusion_pair_metrics.csv`: similarity and neighbor metrics for the repeated confusion pairs.
- `data/structure_summary.csv`: post-hoc species/organ association and cross-space cluster agreement.
- `assets/cluster_sheets/`: all 160 centroid-nearest contact sheets.
- `assets/nn_galleries/`: BioCLIP and DINO galleries for all 17 all-four-wrong queries.
- `assets/pair_sheets/` and `assets/plots/`: confusion-pair representative images and global PCA/UMAP panels.

The persisted source vectors are in `outputs/bioclip25_strict_embeddings/embeddings.npz` and `outputs/dinov3_strict_embeddings/embeddings.npz`.
